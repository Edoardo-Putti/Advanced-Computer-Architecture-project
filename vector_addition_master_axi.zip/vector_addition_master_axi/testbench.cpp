#include <stdio.h>
#include <stdlib.h>
#include "ap_int.h"
#define N 16000
#define X 20

void kernel(ap_uint<512> *a, ap_uint<512> *b, ap_uint<512> *c, float d);

int main(){

	float aCPU[N], aFPGA[N], b[N], c[N], d;

	srand(0);
	d = (float) rand() / ((float) (RAND_MAX/X));
	for(int i = 0; i < N; i++){
		b[i] = (float) rand() / ((float) (RAND_MAX/X));
		c[i] = (float) rand() / ((float) (RAND_MAX/X));
	}
	for(int i = 0; i < N; i++){
		aCPU[i] = b[i] + c[i]*d;
	}

	kernel((ap_uint<512>*)aFPGA, (ap_uint<512>*)b, (ap_uint<512>*)c, d);

	for(int i = 0; i < N; i++){
		if(aCPU[i] != aFPGA[i]){
			printf("Error at index %d: %f != %f\n", i, aCPU[i], aFPGA[i]);
			return 1;
		}
	}

	return 0;

}
